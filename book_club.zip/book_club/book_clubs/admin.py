from django.contrib import admin

from .models import Genre, Entry

admin.site.register(Genre)
admin.site.register(Entry)
