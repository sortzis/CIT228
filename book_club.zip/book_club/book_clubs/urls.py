"""Defines URL patterns for book_clubs."""

from django.urls import path

from . import views

app_name = 'book_clubs'
urlpatterns = [
    # Home page
    path('', views.index, name='index'),
    # Page that shows all genres.
    path('genres/', views.genres, name='genres'),
    # Detail page for a single genre.
    path('genres/<int:genre_id>/', views.genre, name='genre'),
    # Page for adding a new Genre
    path('new_genre/', views.new_genre, name='new_genre'),
    # Page for adding a new entry
    path('new_entry/<int:genre_id>/', views.new_entry, name='new_entry'),
    # Page for editing an entry.
    path('edit_entry/<int:entry_id>/', views.edit_entry, name='edit_entry'),
]