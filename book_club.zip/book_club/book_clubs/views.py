from django.shortcuts import render, redirect

from .models import Genre, Entry
from .forms import GenreForm, EntryForm

def index(request):
    """The home page for Book Club."""
    return render(request, 'book_clubs/index.html')

def genres(request):
    """Show all genres."""
    genres = Genre.objects.order_by('date_added')
    context = {'genres': genres}
    return render(request, 'book_clubs/genres.html', context)

def genre(request, genre_id):
    """Show a single genre and all of its entries."""
    genre = Genre.objects.get(id=genre_id)
    entries = genre.entry_set.order_by('-date_added')
    context = {'genre': genre, 'entries': entries}
    return render(request, 'book_clubs/genre.html', context)

def new_genre(request):
    """Add a new topic."""
    if request.method != 'POST':
        # No data submitted; create a blank form.
        form = GenreForm()
    else:
        # POST data submitted; process data.
        form = GenreForm(data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_clubs:genres')

    # Display a blank or invalid form.
    context = {'form': form}
    return render(request, 'book_clubs/new_genre.html', context)

def new_entry(request, genre_id):
    """Add a new entry for a particular genre."""
    genre = Genre.objects.get(id=genre_id)

    if request.method != 'POST':
        #No data submitted; create a blank form.
        form = EntryForm()
    else:
        # POST data submitted; process data.
        form = EntryForm(data=request.POST)
        if form.is_valid():
            new_entry = form.save(commit=False)
            new_entry.genre = genre
            new_entry.save()
            return redirect('book_clubs:genre', genre_id=genre_id)

    # Display a blank or invalid form.
    context = {'genre': genre, 'form': form}
    return render(request, 'book_clubs/new_entry.html', context)

def edit_entry(request, entry_id):
    """Edit an existing entry."""
    entry = Entry.objects.get(id=entry_id)
    genre = entry.genre

    if request.method != 'POST':
        # Initial request; pre-fill form with the current entry.
        form = EntryForm(instance=entry)
    else:
        # POST data submitted; process data.
        form = EntryForm(instance=entry, data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_clubs:genre', genre_id=genre.id)

    context = {'entry': entry, 'genre': genre, 'form': form}
    return render(request, 'book_clubs/edit_entry.html', context)