from django import forms

from .models import Genre, Entry

class GenreForm(forms.ModelForm):
    class Meta:
        model = Genre
        fields = ['text']
        labels = {'text': ''}

class EntryForm(forms.ModelForm):
    class Meta:
        model = Entry
        fields = ['text']
        labels = {'text': 'Entry:'}
        widgets = {'text': forms.Textarea(attrs={'cols': 80})}